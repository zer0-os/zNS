# ZNS Flow Diagrams

## Domain Content Discovery
![pic](./img/discovery.jpg)

## Domain Registration
![pic](./img/register.jpg)

## Domain Transfer
![pic](./img/transfer.jpg)

## Domain Revocation
![pic](./img/revoke.jpg)