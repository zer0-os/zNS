[![codecov](https://codecov.io/gh/zer0-os/zNS/branch/master/graph/badge.svg?token=1L1P9CO4IU)](https://codecov.io/gh/zer0-os/zNS)

[![CircleCI](https://dl.circleci.com/status-badge/img/gh/zer0-os/zNS/tree/development.svg?style=svg)](https://dl.circleci.com/status-badge/redirect/gh/zer0-os/zNS/tree/development)

# zNS

### [System Architecture](./docs/architecture.md)
### [Smart Contract Docs](./docs/contracts)
### [Flow Diagrams](./docs/flows.md)