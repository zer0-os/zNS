export const tagFile = "git-tag.txt";
export const tagFilePath = `${process.cwd()}/artifacts/${tagFile}`;
