module.exports = {
  skipFiles: [
    'utils/StringUtils.sol',
    'token/mocks',
    'upgrade-test-mocks'
  ]
};
